﻿using System;

public class Analyser
{
	public Analyser()
	{
        // default constructor -- inits go here
	}
}
