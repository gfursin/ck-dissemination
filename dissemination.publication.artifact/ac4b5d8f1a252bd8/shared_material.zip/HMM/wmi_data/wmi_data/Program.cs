﻿using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.ServiceProcess;
using System.Threading;

using Accord;
using Accord.MachineLearning;
using Accord.Math;
using Accord.Neuro;
using Accord.Statistics.Models.Markov;


namespace wmi_data
{
    class Program
    {
        static void Main(string[] args)
        {
            /// <summary>
            /// This software will attempt to autonomously detect faults within a system, and then probabilistically determine their root causes.
            /// It operates by periodically sampling and storing a systems configuration, and then running a set of fitness tests.
            /// Using the results of the fitness tests, systems configurations are categorised as either valid, or invalid.

            /// From this point, the stored systems configurations are used to calculate entropy for all collected properties and values.
            /// If the systems configuration is valid, the database is updated with the working configuration, and the software enters a sleep state until its next periodic interval occurs.
            /// If the systems configuration is invalid (i.e., one or more of the fitness tests fail), then the software attempts to determine the source of the fault.

            /// Determining the source of the fault is based on locating and classifying expected and unexpected changes within the systems configuration.
            /// Previous, known valid configurations are compared to the invalid configuration by having their respective values' entropy evaluated.
            /// Each value has an expected 'entropy profile'; an expected amount of change or persistence. 

            /// Any values that fail to meet the expected entropy profile, are put forth and stored in a log file as potential sources of the fault.
            /// Higher variance of the entropy profile is assumed to be an indicator of a greater probability of being the source of the fault in question.
            /// </summary>


            // GLOBAL VARS - BEGIN

            int int_Polling_Interval_In_Seconds = 1000 * 60 * 1;                                                // determines how often the application should poll for systems configuration data.
            int int_Max_Number_Of_Datasets = 30;                                                                // controls how much data should be stored locally by the service; more means less elasticity.
            string str_DataPath = System.Environment.CurrentDirectory + @"\data\";                              // file location where XML and Schema data is stored; default is local directory + \data
            List<DataSet> lst_WMI_DataSets = new List<DataSet>();                                               // collection of datasets; each dataset is a slice of information that is used to extract patterns.
            List<DataSet> lst_Property_Change_Data = new List<DataSet>();                                       // Stores information related to how often and when properties change in the lst_WMI_DataSet_Collection

            Metrics met_Metrics = new Metrics();                                                                // Tracks performance information related to the detection and classification of anomalies.
            Classifier cla_Classifier = new Classifier();                                                       // Instantiates a classifier; used to determine whether or not a systems configuration is either good or bad.
            Analyser an_Analyser = new Analyser();                                                              // Instantiates an Analyser; used to determine where faults have potentially occurred in the systems configuration.

            int int_False_Negatives = 0;                                                                        // Application DIDNT detect a fault and a fault IS present -- needs to be verified by a user during metrics calucation.
            int int_False_Positives = 0;                                                                        // Application DID detect a fault and a fault IS NOT present.
            int int_True_Negatives = 0;                                                                         // Application DIDNT detect a fault and a fault IS NOT present.
            int int_True_Positives = 0;                                                                         // Application DID detect a fault and a fault IS present.

            int int_Total_Configurations_Examined = 0;                                                          // The number of configurations the framework examined -- not just the number in collection.

            // GLOBAL VARS - FINISH

            // ESTABLISH ENVIRONMENT - BEGIN

            Core.CreateDataSubfolder(str_DataPath);                                                             // Create Data Subfolder -- this folder houses copies of the DataSets in XML Format.
            Core.MaintainDataFolder(str_DataPath, int_Max_Number_Of_Datasets);                                  // Ensures proper file inputs.                             
            lst_WMI_DataSets = Core.LoadDataSetsFromFiles(str_DataPath, int_Max_Number_Of_Datasets);            // looks for and attempt to load existing data from data subfolder.
            
            int_True_Negatives = lst_WMI_DataSets.Count;                                                        // Update the number of non-faulty detections to the number of successful configurations
            int_Total_Configurations_Examined = lst_WMI_DataSets.Count;                                         // Update the number of configurations examined to the current number loaded from disk

            Dictionary<string, string> dic_WMI_Classes = Core.BuildWMIClassDictionary();                        // Stores a list of WMI classes mapped to unique IDs; used for aggregating WMI data and mapping rows to correct instances/feature sets.
            Core.TestWMIConnectivity();                                                                         // Tests the WMI service.


            // TRAIN HIDDEN MARKOV MODELS IF FILES WERE LOADED.
            if (lst_WMI_DataSets.Count > 1)
                an_Analyser.LoadHiddenMarkovModels(lst_WMI_DataSets, dic_WMI_Classes);

            // ESTABLISH ENVIRONMENT - FINISH


            // INFINITE LOOP - BEGIN 

            while (true)
            {
                // create a DataSet object; stores a collection of DataTables. Each table is populated with WMI information; one table per class.
                DataSet ds_Current_WMI_DataSet = new DataSet();
                ds_Current_WMI_DataSet.DataSetName = Core.WriteDataSetName();
                int_Total_Configurations_Examined++;

                // COLLECT DATA

                // foreach WMI class provided, gather WMI information and add it to a DataSet that represents the current system's configuration.
                foreach (string str_WMI_Class in dic_WMI_Classes.Keys)
                {

                    // build and execute a WMI query using the WMI_class. 
                    ManagementObjectSearcher os_WMI_Query_String = new ManagementObjectSearcher(@"root\CIMV2", "SELECT * FROM " + str_WMI_Class);
                    ManagementObjectCollection moc_Current_WMI_Data_Search_Results = os_WMI_Query_String.Get();

                    // create a DataTable with the name of the WMI_Class.
                    DataTable dt = new DataTable(str_WMI_Class);

                    // get the WMI data, and set the TableName
                    dt = Core.GetData(moc_Current_WMI_Data_Search_Results);
                    dt.TableName = str_WMI_Class;

                    // add the table to the dataset.
                    ds_Current_WMI_DataSet.Tables.Add(dt);

                }

                // CLASSIFY SYSTEM STATE

                // classify the configuration; is the system in a good or faulty state?
                bool boo_System_State = cla_Classifier.Run();

                // ON FAILURE, DETERMINE ROOT CAUSE

                // if system is in a false state, double check to see if we found a false positive.
                if (boo_System_State == false)
                {
                    Classifier cla_Double_Check = new Classifier();

                    bool boo_System_State_Double_Check = cla_Double_Check.Run();

                    if (boo_System_State_Double_Check == true)
                    {
                        // if we find a false positive, drop this configuration, update the number of false positives found, and carry on as normal:
                        int_False_Positives++;
                        boo_System_State = true;
                    }

                }

                // if faulty, produce a list of possible sources -- i.e. unexpected changes in entropy vectors within the systems configurations
                if (boo_System_State == false)
                {
                    Console.WriteLine("fault detected. verifying result...");

                    // begin collecting metrics
                    met_Metrics.Start();

                    // update true positives
                    int_True_Positives++;

                    // add the faulty dataset to the current list of datasets.
                    lst_WMI_DataSets.Add(ds_Current_WMI_DataSet);

                    // if a fault has been detected, compare the previous systems configurations with the current configuration.
                    // comparison consists of understanding when property data should and should not change, and returning a list of properties that had unexpected behaviours

                    // using the analyser, pass the current dataset collection, property change collection, WMI class dictionary, and the current faulting dataset)
                    an_Analyser.ExamineFault(lst_WMI_DataSets, dic_WMI_Classes);

                    // stop collecting metrics and generate observation data
                    met_Metrics.Stop(an_Analyser, int_False_Negatives, int_False_Positives, int_True_Negatives, int_True_Positives, int_Total_Configurations_Examined);

                    // exit
                    return;
                }

                // ON SUCCESS, AGGREGATE DATA

                // if not faulty, update the list of datasets and their expected vectors.
                else
                {
                    // update true negatives
                    int_True_Negatives++;

                    // update the list of DataSets - the latest configuration information is added to the lst_WMI_DataSet_Collection
                    lst_WMI_DataSets.Add(ds_Current_WMI_DataSet);

                    // if the list has more than max_number_of_datasets members, drop the oldest members.
                    lst_WMI_DataSets = Core.TrimListOfDataSets(int_Max_Number_Of_Datasets, lst_WMI_DataSets);

                    // write the current in memory dataset collection to disk 
                    Core.WriteDataSetsToFolder(str_DataPath, lst_WMI_DataSets);

                    // remove files that are not required after the write; this includes old/stagnant datasets.
                    Core.MaintainDataFolder(str_DataPath, int_Max_Number_Of_Datasets);

                    // update Hidden Markov Models
                    // an_Analyser.UpdateHMMs();
                }

                Console.WriteLine("Total size of DataSet Collection: {0}\t{1}\t\t System State is: {2}", ds_Current_WMI_DataSet.DataSetName, Core.GetObjectSize(lst_WMI_DataSets), boo_System_State.ToString());
                // Core.WriteDataSetDataToXmlFile(".", ds_Current_WMI_DataSet.DataSetName + "data.xml");
                // using Thread.Sleep will cause 'drift' when executing the data-gathering; a Timer would fix this however this approach requires a volatile boolean and threading logic to avoid overlapping.
                Thread.Sleep(int_Polling_Interval_In_Seconds);

            }

            // INFINITE LOOP - FINISH
        }
    }

    static public class Core
    {
        // basic administration object; used to facilitate all major step-functions.

        public static Dictionary<string, string> BuildWMIClassDictionary()
        {
            Dictionary<string, string> dic_Temporary_Dictionary = new Dictionary<string, string>();

            dic_Temporary_Dictionary.Add("Win32_BIOS", "Version");
            dic_Temporary_Dictionary.Add("Win32_ComputerSystem", "Caption");
            dic_Temporary_Dictionary.Add("Win32_DiskDrive", "DeviceID");
            // dic_Temporary_Dictionary.Add("Win32_IP4RouteTable", "Caption");         // added 14.04.2013 -- bug with this entry; no unique column to work with. 
            dic_Temporary_Dictionary.Add("Win32_LogicalDisk", "DeviceID");
            dic_Temporary_Dictionary.Add("Win32_NetworkAdapter", "Caption");
            dic_Temporary_Dictionary.Add("Win32_OperatingSystem", "SerialNumber");  // added 14.04.2013
            dic_Temporary_Dictionary.Add("Win32_PhysicalMemory", "BankLabel");
            dic_Temporary_Dictionary.Add("Win32_Processor", "ProcessorId");
            dic_Temporary_Dictionary.Add("Win32_QuickFixEngineering", "HotFixID");  // added 14.04.2013
            dic_Temporary_Dictionary.Add("Win32_Service", "Caption");
            dic_Temporary_Dictionary.Add("Win32_SystemAccount", "SID");             // added 14.04.2013
            // dic_Temporary_Dictionary.Add("Win32_Registry", "Caption");              // added 20.09.2013 

            return dic_Temporary_Dictionary;
        } // end BuildWMIClassDictionary
        public static T Clone<T>(T source)
        {
            ///<summary> 
            /// Deep clones any serialisable object.
            ///</summary>

            // source: http://stackoverflow.com/questions/78536/deep-cloning-objects-in-c-sharp

            if (!typeof(T).IsSerializable)
            {
                throw new ArgumentException("The type must be serializable.", "source");
            }

            // Don't serialize a null object, simply return the default for that object
            if (Object.ReferenceEquals(source, null))
            {
                return default(T);
            }

            IFormatter formatter = new BinaryFormatter();
            Stream stream = new MemoryStream();
            using (stream)
            {
                formatter.Serialize(stream, source);
                stream.Seek(0, SeekOrigin.Begin);
                return (T)formatter.Deserialize(stream);
            }
        } // end Clone;
        public static bool CreateDataSubfolder(string str_DataPath)
        {
            /// Create Data Subfolder -- this folder houses copies of the DataSets in XML Format.

            try
            {
                // if str_FolderName !exist, create it.
                if (!Directory.Exists(str_DataPath))
                {
                    Directory.CreateDirectory(str_DataPath);
                }
                return true;

            }
            catch (Exception e)
            {
                Console.WriteLine("error creating subdirectory {0}", e.Message);
                return false;
            }

        } // end CreateDataSubfolder
        public static DataTable GetData(this ManagementObjectCollection moc_Object_Collection)
        {
            /// <summary>
            /// Returns all data in the specified Management Object Collection as a DataTable.
            /// </summary>
            DataTable dt_Table = new DataTable();

            foreach (ManagementObject mo_Current_Object in moc_Object_Collection)
            {
                // populate the table columns / build the table
                if (dt_Table.Columns.Count == 0)
                {
                    IEnumerator IE = mo_Current_Object.Properties.GetEnumerator();
                    while (IE.MoveNext())
                    {
                        PropertyData pd_Current_Property = IE.Current as PropertyData;
                        if (pd_Current_Property != null)
                        {
                            try
                            {
                                dt_Table.Columns.Add(pd_Current_Property.Name.ToString(), CimConverter.Cim2SystemType(pd_Current_Property));
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("{0} {1} {2}", e.Message, pd_Current_Property.Type, pd_Current_Property.Name);
                                continue;
                            }
                        }
                    }
                }

                // populate the table.

                // build a new row which will be added to the table.
                DataRow dr_Data_Row = dt_Table.NewRow();

                foreach (DataColumn dc_Data_Column in dt_Table.Columns)
                {
                    // if the object is an array, make sure all objects in that array are stored...
                    if (dc_Data_Column.DataType.IsArray)
                    {
                        // convert it to an array, then add it to the row.
                        var var_Temporary_Object = mo_Current_Object[dc_Data_Column.ColumnName]; // THIS DOES GRAB THE DATA....
                        dr_Data_Row[dc_Data_Column] = var_Temporary_Object;
                        // Console.WriteLine("{0} {1}", var_Temporary_Object.GetType(), var_Temporary_Object);
                    }

                    // if the object is a DateTime object, convert it.
                    if (dc_Data_Column.DataType.Equals(typeof(DateTime)))
                    {
                        var var_Temporary_Object = CimConverter.ToDateTime(mo_Current_Object[dc_Data_Column.ColumnName]);
                        dr_Data_Row[dc_Data_Column] = var_Temporary_Object;
                        continue;
                    }

                    // else treat as a single object and either insert it into the data row, or place a null.
                    else
                    {

                        var var_Temporary_Object = mo_Current_Object[dc_Data_Column.ColumnName];
                        dr_Data_Row[dc_Data_Column] = var_Temporary_Object ?? DBNull.Value;
                        continue;
                    }
                }
                dt_Table.Rows.Add(dr_Data_Row);
            }

            return dt_Table;
        } // end GetData
        public static int GetObjectSize(object TestObject)
        {
            // taken from http://stackoverflow.com/questions/605621/how-to-get-object-size-in-memory

            /// <summary>
            /// Calculates the lenght in bytes of an object 
            /// and returns the size 
            /// </summary>
            /// <param name="TestObject">Any object.</param>
            /// <returns></returns>

            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            byte[] Array;
            bf.Serialize(ms, TestObject);
            Array = ms.ToArray();

            return Array.Length;

        } // end GetObjectSize
        public static void PrintDataTable(DataTable dt_DataTable)
        {
            /// <summary>
            /// This method takes in a DataTable and prints it to console.
            /// </summary>

            foreach (DataColumn dc_Current_DataColumn in dt_DataTable.Columns)
            {
                Console.Write(dc_Current_DataColumn.ColumnName + ",");
            }

            // insert new line at end of columns
            Console.WriteLine();

            foreach (DataRow dr_Current_DataRow in dt_DataTable.Rows)
            {
                foreach (object obj_Item in dr_Current_DataRow.ItemArray)
                {
                    // if the item is an array, print everything in the array.
                    if (obj_Item.GetType().IsArray)
                    {
                        // do voodoo magic here. http://stackoverflow.com/questions/10745542/object-to-string-array
                        // explicitly casting an object[] to a string[] fails.
                        // The reason the cast fails is that although arrays of reference types are covariant, arrays of value types are not.
                        // instead we have to use some ugly lamda expression to iterate through the object[] via a forced IEnumerable.

                        string[] strA_Temporary_Array = ((IEnumerable)obj_Item).Cast<object>().Select(x => x.ToString()).ToArray();

                        string str_Object_As_String = "";

                        // encase the array in a delimiter; 
                        Console.Write("{");
                        foreach (string s in strA_Temporary_Array)
                        {
                            str_Object_As_String = str_Object_As_String + s + ",";
                        }

                        // do this to drop the last ',';
                        str_Object_As_String = str_Object_As_String.Substring(0, str_Object_As_String.Length - 1);

                        Console.Write(str_Object_As_String);

                        // close the array delimiter.
                        Console.Write("},");

                    }
                    // if its not array, just print the item as is.
                    else Console.Write(obj_Item + ",");
                }

                // insert new line for each row.
                Console.WriteLine();
            }

            return;

        } // end PrintDataTable
        public static List<DataSet> LoadDataSetsFromFiles(string str_DataPath, int int_Max_Number_Of_DataSets)
        {
            /// <summary>
            /// This function looks for *_data.xml and corresponding *_schema.xml in the data subdirectory, and attempts to load them into a List of Datasets.
            /// </summary>

            // make sure the data subfolder has only the data we wish to load
            Core.MaintainDataFolder(str_DataPath, int_Max_Number_Of_DataSets);

            // get all the file names in the data subdirectory && order by file creation time in descending order.
            var var_Ordered_List_Of_Files_In_Data_Directory = Directory.GetFiles(str_DataPath, "*_data.xml").OrderByDescending(file => new FileInfo(file).CreationTime);
            // RETURNS: System.Linq.OrderedEnumerable`2[System.String,System.DateTime]

            // convert this object type to a list of strings.
            List<string> lst_Xml_Data_Files = var_Ordered_List_Of_Files_In_Data_Directory.ToList();

            // make sure the list is sorted properly -- this works to order files from oldest to newest due to the naming convention.
            lst_Xml_Data_Files.Sort();

            List<DataSet> lst_DataSets = new List<DataSet>();

            // for each of these entries, load the schema, and the data into a data set, and add it to the dataset collection.
            if (lst_Xml_Data_Files.Count >= 1)
            {
                // if we have at least one xml data file then...
                Console.WriteLine("found {0} existing .xml data files in data subdirectory; attempting to populate.", lst_Xml_Data_Files.Count.ToString());

                try
                {
                    // for each set of files, load a data schema, and a dataset--then add it to a List                 
                    foreach (string @s in lst_Xml_Data_Files)
                    {
                        DataSet ds_Temp_DataSet = new DataSet();

                        string str_Data_File_Name = @s;
                        string str_Schema_File_Name = @s.Replace("_data.xml", "_schema.xml");

                        Core.ReadDataSetSchemaFromXmlFile(str_Schema_File_Name, ds_Temp_DataSet);
                        Core.ReadDataSetFromXmlFile(str_Data_File_Name, ds_Temp_DataSet);

                        // add the newly populated dataset to the list of datasets
                        lst_DataSets.Add(ds_Temp_DataSet);

                    }

                    // make sure list_DataSets is properly sorted, and return it.
                    return lst_DataSets;
                }

                catch (Exception e)
                {
                    // if reading the files fails for some reason, report why and return null
                    Console.WriteLine("error reading .xml data files in data subdirectory. {0}", e.Message);
                    return lst_DataSets; // RETURNING NULL HERE WILL PRODUCE A DE-REFERENCING PROBLEM LATER. RATHER THAN DO THIS WE SOFT FAIL.
                }
            }
            else
            {
                // if there are no files to load, return null.
                Console.WriteLine("no previously saved data found; using empty dataset collection.");
                return lst_DataSets;
            }


        } // end LoadData
        public static bool MaintainDataFolder_BUGGED(string str_DataPath, int int_Max_Number_Of_Datasets)
        {

            /// <summary>
            /// This function ensures the following conditions:
            ///     1. A data subfolder exists.
            ///     2. The data subfolder can be read/written to.
            ///     3. The data subfolder contains no more than the number of files expected (determined via max_number_of_datasets)
            ///     4. Each data and schema file match another of the same name; strays are deleted.
            ///     
            /// If the first two conditions fail, the function returns false and the application halts.
            /// If the third condition fails, the oldest files not within the max_number_of_datasets are deleted. 
            /// 
            /// Steps:
            /// 1. Get the path to the data subdirectory
            /// 2. Get all the file names in the data subdirectory
            /// 3. Organise these file names by oldest at the top, to newest at the bottom
            /// 4. Remove the oldest K files in the data sub directory (k is the number of files in the directory, less the max number of datasets)
            /// 
            /// Expected Result: The newest files should be left in the directory (up to max_number_of_datasets) including those from the currently running application.
            /// </summary>


            // get all the file names in the data subdirectory && order by file creation time in descending order.
            var var_Ordered_List_Of_Files_In_Data_Directory = Directory.GetFiles(str_DataPath, "*.xml").OrderByDescending(file => new FileInfo(file).CreationTime);
            // RETURNS: System.Linq.OrderedEnumerable`2[System.String,System.DateTime]

            // convert this object type to a list of strings.
            List<string> lst_Files_And_Creation_Dates = var_Ordered_List_Of_Files_In_Data_Directory.ToList();

            // files listed on the bottom of this list are to be deleted first.
            // to determine which files are deleted, we take the number of expected files from the top.
            // these files are kept; all others are removed. 

            // to get the number of files expected:
            //  a dataset has 2 files associated with it; a _data and _schema file.
            //  therefore, we take the list length and subtract max_number_of_datasets * 2 from it.
            List<string> lst_Files_To_Be_Deleted = new List<string>();

            // verify there is a schema file for every data file...
            // this is terribly written; need to revisit when not in a rush and fix this.
            foreach (string s in lst_Files_And_Creation_Dates)
            {
                if (s.Contains("data.xml"))
                {
                    string str_Data_File = s;
                    string str_Schema_File = s.Replace("data.xml", "schema.xml");

                    if (lst_Files_And_Creation_Dates.Contains(str_Data_File) && lst_Files_And_Creation_Dates.Contains(str_Schema_File))
                        continue;
                    else
                    {
                        // delete
                        lst_Files_To_Be_Deleted.Add(str_Data_File);
                        lst_Files_To_Be_Deleted.Add(str_Schema_File);
                    }
                }
                if (s.Contains("schema.xml"))
                {
                    string str_Schema_File = s;
                    string str_Data_File = s.Replace("schema.xml", "data.xml");

                    if (lst_Files_And_Creation_Dates.Contains(str_Data_File) && lst_Files_And_Creation_Dates.Contains(str_Schema_File))
                        continue;
                    else 
                    { 
                        // delete files
                        lst_Files_To_Be_Deleted.Add(str_Data_File);
                        lst_Files_To_Be_Deleted.Add(str_Schema_File);
                    }

                }
            }

            // delete the files one at a time by iterating the list.
            foreach (string s in lst_Files_To_Be_Deleted)
            {
                FileInfo fi_temp = new FileInfo(@s);
                fi_temp.Delete();
            }

            // next see if the total of files to delete is correct

            int int_Expected_Number_Of_Files = int_Max_Number_Of_Datasets * 2;
            int int_Number_Of_Files_To_Remove = lst_Files_And_Creation_Dates.Count - int_Expected_Number_Of_Files;

            // if we have a 0 or negative number, then we need to abort; there are no files to delete. 
            if (int_Number_Of_Files_To_Remove < 1)
            {
                return false;
            }

            // prepare to delete files -- get the range of files to be deleted.
            int int_Start_Index_To_Get_File_Names = lst_Files_And_Creation_Dates.Count - int_Number_Of_Files_To_Remove;
            int int_Count_Of_Files_To_Be_Deleted = lst_Files_And_Creation_Dates.Count - int_Start_Index_To_Get_File_Names;

            // put the files to be deleted in a list, using the range that was just created.
            lst_Files_To_Be_Deleted = lst_Files_And_Creation_Dates.GetRange(int_Start_Index_To_Get_File_Names, int_Count_Of_Files_To_Be_Deleted);

            // delete the files one at a time by iterating the list.    
            foreach (string s in lst_Files_To_Be_Deleted)
            {
                FileInfo fi_temp = new FileInfo(@s);
                fi_temp.Delete();
            }

            // display output.
            // Console.WriteLine("total files in folder: {0}, total files to remove {1}", lst_Files_And_Creation_Dates.Count, int_Number_Of_Files_To_Remove);

            return true;
        } // end MaintainDataFolder_BUGGED

        public static bool MaintainDataFolder(string str_DataPath, int int_Max_Number_Of_Datasets)
        {

            /// <summary>
            /// This function ensures the following conditions:
            ///     1. A data subfolder exists.
            ///     2. The data subfolder can be read/written to.
            ///     3. The data subfolder contains no more than the number of files expected (determined via max_number_of_datasets)
            ///     
            /// If the first two conditions fail, the function returns false and the application halts.
            /// If the third condition fails, the oldest files not within the max_number_of_datasets are deleted. 
            /// 
            /// Steps:
            /// 1. Get the path to the data subdirectory
            /// 2. Get all the file names in the data subdirectory
            /// 3. Organise these file names by oldest at the top, to newest at the bottom
            /// 4. Remove the oldest K files in the data sub directory (k is the number of files in the directory, less the max number of datasets)
            /// 
            /// Expected Result: The newest files should be left in the directory (up to max_number_of_datasets) including those from the currently running application.
            /// </summary>


            // get all the file names in the data subdirectory && order by file creation time in descending order.
            var var_Ordered_List_Of_Files_In_Data_Directory = Directory.GetFiles(str_DataPath, "*.xml").OrderByDescending(file => new FileInfo(file).CreationTime);
            // RETURNS: System.Linq.OrderedEnumerable`2[System.String,System.DateTime]

            // convert this object type to a list of strings.
            List<string> lst_Files_And_Creation_Dates = var_Ordered_List_Of_Files_In_Data_Directory.ToList();

            // files listed on the bottom of this list are to be deleted first.
            // to determine which files are deleted, we take the number of expected files from the top.
            // these files are kept; all others are removed. 

            // to get the number of files expected:
            //  a dataset has 2 files associated with it; a _data and _schema file.
            //  therefore, we take the list length and subtract max_number_of_datasets * 2 from it.

            int int_Expected_Number_Of_Files = int_Max_Number_Of_Datasets * 2;
            int int_Number_Of_Files_To_Remove = lst_Files_And_Creation_Dates.Count - int_Expected_Number_Of_Files;

            // if we have a 0 or negative number, then we need to abort; there are no files to delete. 
            if (int_Number_Of_Files_To_Remove < 1)
            {
                return false;
            }

            // prepare to delete files -- get the range of files to be deleted.
            int int_Start_Index_To_Get_File_Names = lst_Files_And_Creation_Dates.Count - int_Number_Of_Files_To_Remove;
            int int_Count_Of_Files_To_Be_Deleted = lst_Files_And_Creation_Dates.Count - int_Start_Index_To_Get_File_Names;

            // put the files to be deleted in a list, using the range that was just created.
            List<string> lst_Files_To_Be_Deleted = lst_Files_And_Creation_Dates.GetRange(int_Start_Index_To_Get_File_Names, int_Count_Of_Files_To_Be_Deleted);

            // delete the files one at a time by iterating the list.
            foreach (string s in lst_Files_To_Be_Deleted)
            {
                FileInfo fi_temp = new FileInfo(@s);
                fi_temp.Delete();
            }

            // display output.
            // Console.WriteLine("total files in folder: {0}, total files to remove {1}", lst_Files_And_Creation_Dates.Count, int_Number_Of_Files_To_Remove);

            return true;
        } // end MaintainDataFolder
        public static DataSet ReadDataSetFromXmlFile(string str_Path_To_Xml_File, DataSet ds_DataSet)
        {
            /// Reads in an XML file and attempts to return it as a DataSet.
            /// THIS FUNCTION MUST HAVE ITS SCHEMA POPULATED BEFORE USE -- SEE ReadDataSetSchemaFromXmlSchema()
            try
            {
                StreamReader sr = new StreamReader(str_Path_To_Xml_File);
                ds_DataSet.ReadXml(sr);
                sr.Close();

                return ds_DataSet;
            }
            catch (Exception e)
            {
                Console.WriteLine("error in reading xml data from file {0} - {1}", str_Path_To_Xml_File, e.Message);
                return null;
            }

        } // end ReadDataSetFromXmlFile
        public static DataSet ReadDataSetSchemaFromXmlFile(string str_Path_To_Schema_Xml, DataSet ds_DataSet)
        {
            /// returns a dataset populated with an XML schema file.
            /// TO BE USED BEFORE POPULATING RAW XML DATA INTO A DATASET.

            try
            {
                // Using the path to the schema xml, populate an XMLReader Object, via a file reader.
                StreamReader sr = new StreamReader(str_Path_To_Schema_Xml);
                ds_DataSet.ReadXmlSchema(sr);
                sr.Close();

                return ds_DataSet;
            }
            catch (Exception e)
            {
                Console.WriteLine("error in reading xml schema from file {0} - {1}", str_Path_To_Schema_Xml, e.Message);
                return null;
            }
        } // end ReadDataSetSchemaFromXmlFile
        public static List<DataSet> TrimListOfDataSets(int int_Max_List_Length, List<DataSet> lst_DataSetCollection)
        {
            ///<summary>
            /// Expires the oldest items in the lst_DataSetCollection until the list count is MaxListLength.
            ///</summary>

            // get the length of the supplied list
            int int_Current_List_Length = lst_DataSetCollection.Count();

            // get number of items to remove 
            int int_Total_Items_To_Remove = int_Current_List_Length - int_Max_List_Length;

            // make sure the list is not less than the expected value; 
            // at this point the list should always be equal to the MaxListLength.
            if (int_Total_Items_To_Remove < 1)
            {
                // return the list without making changes.
                return lst_DataSetCollection;
            }
            else
            {
                // if there are 1 or more items to remove, modify the list of datasets
                // take the number of datasets to remove, and count backwards from the end of the list/collection
                lst_DataSetCollection.RemoveRange((int_Current_List_Length - 1) - int_Total_Items_To_Remove, int_Total_Items_To_Remove);

                // return the modified list
                return lst_DataSetCollection;
            }

        } // end TrimListOfDataSets
        public static ManagementScope TestWMIConnectivity()
        {
            // tests connection to a given WMI service.
            try
            {
                return new ManagementScope(@"root\ccm");
            }
            catch (System.Management.ManagementException e)
            {
                Console.WriteLine("wmi connection failure: {0}", e.Message);
                throw;
            }
        } // end Test_WMI_Service
        public static string[] ToStringArray(object obj_Collection)
        {
            /// <summary>Converts ANY collection to a strong array. </summary>
            /// 
            var collection = obj_Collection as System.Collections.IEnumerable;
            if (collection != null)
            {
                return collection.Cast<object>().Select(x => x.ToString()).ToArray();
            }

            if (obj_Collection == null)
            {
                return new string[] { };
            }

            return new string[] { obj_Collection.ToString() };
        } // end ToStringArray
        public static bool WriteDataSetsToFolder(string str_DataPath, List<DataSet> lst_DataSetCollection)
        {
            /// <summary>
            /// Writes all current DataSets in the DataSet collection to the data subdirectory.
            /// </summary>

            try
            {
                foreach (DataSet ds_DataSet in lst_DataSetCollection)
                {
                    Core.WriteDataSetSchemaToXmlFile(str_DataPath, ds_DataSet);
                    Core.WriteDataSetDataToXmlFile(str_DataPath, ds_DataSet);
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine("failure in writing datasets to data subdirectory. {0} {1}", str_DataPath, e.Message);
                return false;
            }

        } // end WriteDataSetsToFolder
        public static string WriteDataSetName()
        {
            /// <summary>
            /// Sets the name on a DataSet to the following format:
            /// FORMAT: SYSTEMNAME_YYYYMMDD_HHMM
            /// DEFAULT: NewDataSet
            /// </summary>

            string str_DataSetName = "";

            // get the systemname
            str_DataSetName = System.Environment.MachineName.ToString();

            // get the month and day in MMDD format.
            string str_MMDD = DateTime.Now.ToString("MMdd");

            // get get the current time in HHMM 24-hour format.
            string timeHHMM = DateTime.Now.ToString("HHmm", System.Globalization.DateTimeFormatInfo.InvariantInfo);

            str_DataSetName = str_DataSetName + "_" + str_MMDD + "_" + timeHHMM;

            return str_DataSetName;
        } // end WriteDataSetName
        public static bool WriteDataSetDataToXmlFile(string str_DataPath, DataSet ds_DataSet)
        {
            /// <summary>
            /// Takes in a DataSet and writes the data to a file in XML format.
            /// </summary>

            // first, set the dataset name; this will be used as the file name.
            // ds_DataSet.DataSetName = Core.WriteDataSetName(); -- this line, if enabled, produces a rare bug where the schema and dataset data files can be off by 1 minute due to delay in writing.

            // open a file (create or overwrite if necessary), and write the data in XML format using the dataset name.
            try
            {
                FileStream fs = new FileStream(str_DataPath + ds_DataSet.DataSetName + "_data.xml", FileMode.Create);
                ds_DataSet.WriteXml(fs);
                fs.Flush();
                fs.Close();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }

        } // end WriteDataSetToXmlFile
        public static bool WriteDataSetSchemaToXmlFile(string str_DataPath, DataSet ds_DataSet)
        {
            /// <summary>
            /// takes in a dataset and writes its schema information to a file.
            /// </summary>

            // first, set the dataset name; this will be used as the file name.
            // ds_DataSet.DataSetName = Core.WriteDataSetName(); -- this line, if enabled, produces a rare bug where the schema and dataset data files can be off by 1 minute due to delay in writing. 

            // open a file (create or overwrite if necessary), and write the data in XML format, using the dataset name
            try
            {
                FileStream fs = new FileStream(str_DataPath + ds_DataSet.DataSetName + "_schema.xml", FileMode.Create);
                ds_DataSet.WriteXmlSchema(fs);
                fs.Flush();
                fs.Close();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }

        } // end WriteDataSetSchemaToXmlFile
        public static int[] ExtendIntArray(int[] intA_Input_Array)
        {
            // extend array
            int[] intA_Extended_Array = new int[intA_Input_Array.Length + 1];

            // copy contents
            for (int i = 0; i < intA_Input_Array.Length; i++)
            {
                intA_Extended_Array[i] = intA_Input_Array[i];
            }

            // return values.
            return intA_Extended_Array;
        } // end ExtendIntArray
        public static bool ArraysEqual<T>(T[] a1, T[] a2)
        {
            // compares two generic arrays by content, instead of by reference (i.e. ==, !=);
            // taken from http://stackoverflow.com/questions/4423318/how-to-compare-arrays-in-c

            if (ReferenceEquals(a1, a2))
                return true;

            if (a1 == null || a2 == null)
                return false;

            if (a1.Length != a2.Length)
                return false;

            EqualityComparer<T> comparer = EqualityComparer<T>.Default;
            for (int i = 0; i < a1.Length; i++)
            {
                if (!comparer.Equals(a1[i], a2[i])) return false;
            }
            return true;
        } // end ArraysEqual

    }

    public class Analyser
    {

        /// <summary>
        /// This class contains code for analysing WMI data that has been determined to be faulty by the classifier.
        /// </summary>

        /// Once the WMI information gathered it is placed into a 'stack' -- represented by a collection of datasets.
        /// The stack is then converted into a set of simple vectors -- one for each current* property in the WMI data.
        /// 
        /// This vector represents the expected rate of change (i.e. 'entropy') for a particular property.
        /// It is calculated using a 'rolling' average where oldest information is discarded first (FIFO).
        /// This approach permits gradual change and elasticity in acceptable systems behaviour (e.g. web-server traffic ebb and flows).
        /// This is the reason for the int_Max_Number_Of_Datasets value; more datasets means a lower moving average / behaviour; fewer, the converse.
        /// 
        /// Each property is expected to establish one of three standard behaviours: 
        /// High entropy (0.9 or more), Low entropy (0.1 or less), or Undecided (x is between 0.1 and 0.9).
        /// Properties with high entropy are assumed to contain values that change consistently; vis-a-vis Low entropy. 
        /// Those properties outwith these two patterns are ignored -- a subject for later advancement**.
        /// 
        /// Notes:
        /// 
        /// * Current properties are defined as: Those that exist within the last WMI sample taken.
        /// 
        /// It is possible for properties to go missing--namely any device that is hot-swappable, or has a disable feature.
        /// These objects will not show up in the WMI queries once they are removed, and thus their vectors will go missing as well.
        /// 
        /// This fact, combined with the need for differential logic when determining missing properties, makes removed objects hard to evaluate.
        /// To address this particular exigency, a differential method is run on the 'last known good' WMI information and the 'faulty' WMI information.
        /// Any properties determined to be missing are added to a list of probable root causes and their vectors are adjusted accordingly***.
        /// 
        /// ** An argument could be made for stronger behavioural profiling; particularly when classifying the behaviours of properties.
        /// This approach is intended to explore detection of faults using a single, simplified variable and provide a proof of concept for the approach.
        /// This is sometimes classified as 'second-order' behaviours; if successful, those behaviours are to be explored but at a later time.

        /// ***
        /// To find properties that have gone missing a differential MUST be done.
        /// The easiest way to provide this differential is to generate a list of all seen properties in every WMI class that is specified.
        /// This will operate as a 'checklist' for properties... 
        /// Any item not in the last known good working configuration is to be added to a list of potential root causes.


        // LOCAL VARS - BEGIN

        List<string> lst_Possible_Root_Causes = new List<string>();                                     // contains a list of strings of possible root causes for faults in the format of: (WMI_CLASS_NAME)\(UNIQUE_IDENTIFIER_VALUE)\(COLUMN_NAME)
        List<Fault> lst_Faults = new List<Fault>();                                                     // contains a list of potential faults, and a degree of confidence that it is the source of the issue at hand.

        Dictionary<string, int[]> dic_Feature_History_LKG = new Dictionary<string, int[]>();            // contains a set of historical data for features in known good systems configurations
        Dictionary<string, int[]> dic_Feature_History_FLT = new Dictionary<string, int[]>();            // contains a set of historical data for features in both known good and the faulty configuration

        double dbl_Hidden_Markov_Model_Threshold = 0.001;                                              // The minimum amount of change needed for the Markov Model to note a response from its respective inputs.
        Dictionary<string, HiddenMarkovModel> dic_Hidden_Markov_Models = new Dictionary<string, HiddenMarkovModel>(); // stores an identifier (path to property as string), and an associated HMM.

        // LOCAL VARS - END

        public void ExamineFault(List<DataSet> lst_WMI_DataSets, Dictionary<string, string> dic_WMI_Classes)
        {

            /// <summary>
            /// This function is designed to look for differences in systems configuration data to determine the root cause of systems faults.
            /// It operates by using hidden markov models to predict changes in feature data.
            /// The hidden markov models have been trained whilst the system is in a known good state (as determined via the Classifier).
            /// 
            /// in the systems configuration data, both historically known good (LKG) and faulty datasets (FLT) and does a differential analysis
            /// based on the predictive outcomes of their respective feature change data sequences.
            /// </summary>

            // make sure we have at least one comparable set of data to work with.
            if (lst_WMI_DataSets.Count < 2)
            {
                Console.WriteLine("not enough information to perform assessment of faults.");
                return;
            }

            // the faulty configuration is already part of the total datasets, so remove it.
            DataSet ds_Current_WMI_DataSet = lst_WMI_DataSets[lst_WMI_DataSets.Count - 1];
            lst_WMI_DataSets.Remove(lst_WMI_DataSets[lst_WMI_DataSets.Count - 1]);

            // gather the entropy / change data for the LKG configuration
            // create feature history catalogue / dictionary: contains path to feature, and an integer array indicating whether or not the feature changed in previous configurations.
            List<DataSet> lst_Property_Change_Data_LKG = this.GetPropertyChanges(lst_WMI_DataSets, dic_WMI_Classes);
            dic_Feature_History_LKG = this.CataloguePropertyChanges(lst_Property_Change_Data_LKG, dic_WMI_Classes);

            // next, gather the entropy / change data for the FLT configuration
            //  first, trim the dataset so they are equal in length to the LKG set...
            lst_WMI_DataSets.Remove(lst_WMI_DataSets[0]);
            lst_WMI_DataSets.Add(ds_Current_WMI_DataSet);

            // create feature history catalogue / dictionary: contains path to feature, and an integer array indicating whther or not the feature changed in previous configurations.
            List<DataSet> lst_Property_Change_Data_FLT = this.GetPropertyChanges(lst_WMI_DataSets, dic_WMI_Classes);
            dic_Feature_History_FLT = this.CataloguePropertyChanges(lst_Property_Change_Data_FLT, dic_WMI_Classes);

            // the feature history shows how systems properties were behaving.
            // the Hidden Markov Models will try to predict sequences in the feature history.
            // using this premise, if the prediction made by the HMM is wrong, add to suspect root cause list.

            // i.e. whichever process is closer to 1 is expected, so add the one thats closer to zero...
            // or, if it's not in the LKG dictionary, add it to the list.

            double dbl_Result_From_LKG = 0;
            double dbl_Result_From_FLT = 0;

            // get expected evaluations (LKG) 
            foreach (KeyValuePair<string, int[]> KVP in dic_Feature_History_LKG)
            {

                // if the property is in the failing dictionary, do a comparison.
                if (dic_Feature_History_FLT.ContainsKey(KVP.Key))
                {

                    string str_Current_LKG_Key = KVP.Key;
                    int[] intA_Current_LKG_Values = KVP.Value;

                    string str_Current_FLT_Key = KVP.Key;
                    int[] intA_Current_FLT_Values = dic_Feature_History_FLT[KVP.Key];

                    // if there is a change in the property sequences, they need to be evaluated.
                    if (Core.ArraysEqual(intA_Current_FLT_Values, intA_Current_LKG_Values) == false)
                    {
                        // do hidden markov model evaluations
                        dbl_Result_From_LKG = dic_Hidden_Markov_Models[KVP.Key].Evaluate(intA_Current_LKG_Values);
                        dbl_Result_From_FLT = dic_Hidden_Markov_Models[KVP.Key].Evaluate(intA_Current_FLT_Values);

                        // if the evaluation in the faulting configuration is closer to zero than the last known good configuration...
                        // then we have a possible fault; add it to fault list.
                        if (dbl_Result_From_FLT < dbl_Result_From_LKG)
                        {
                            Fault f = new Fault();
                            f.Source = KVP.Key;
                            f.Confidence = Math.Abs(dbl_Result_From_FLT - dbl_Result_From_LKG);
                            lst_Faults.Add(f);
                        }
                    }
                    else continue;

                }

                // if the property is not in the failing configuration dictionary, add it to the fault list with default value of 0.0.
                if (dic_Feature_History_FLT.ContainsKey(KVP.Key) == false)
                {
                    Fault f = new Fault();
                    f.Source = KVP.Key;
                    f.Confidence = 0.0;
                    lst_Faults.Add(f);
                    continue;
                }

            }

            // once complete, sort the list by likelihood...
            var var_Faults = lst_Faults.OrderByDescending(x => x.Confidence);

            foreach (Fault f in var_Faults)
            {
                Console.WriteLine("{0},{1}", f.Source, f.Confidence);
            }

            return;


        } // end ExamineFault
        private void UpdateHiddenMarkovModels(List<DataSet> lst_WMI_DataSets, Dictionary<string, string> dic_WMI_Classes)
        {
            // updates the learning knowledge of the HMMs

            // gather the entropy / change data         
            List<DataSet> lst_Property_Change_Data = this.GetPropertyChanges(lst_WMI_DataSets, dic_WMI_Classes);

            // create feature history catalogue / dictionary: contains  path to feature, and an integer array indicating whether or not the feature changed in previous configurations.
            dic_Feature_History_LKG = this.CataloguePropertyChanges(lst_Property_Change_Data, dic_WMI_Classes);

            // if dic_Feature_History_LKG key in dic_Hidden_Markov_Models, update value.
            // if ! in dic_HMM, add Key, update value

            foreach (KeyValuePair<string, int[]> KVP in dic_Feature_History_LKG)
            {
                if (dic_Hidden_Markov_Models.ContainsKey(KVP.Key))
                {
                    // access the specific HMM associated with this key.
                    HiddenMarkovModel hmm_Current_Model = dic_Hidden_Markov_Models[KVP.Key];

                    // fracture the sequences into a series of int[]'s. this will be used to train the HMM.
                    List<int[]> lstIA_Training_Sequences = this.FractureIntSequence(KVP.Value);

                    // set the jagged array's length to the total number of datasets -- because the total number of datasets - 1 is the number of inputs to parse.
                    int[][] intAA_Training_Sequences = new int[lst_WMI_DataSets.Count - 1][];

                    // convert list<int[]> to int[][] -- needed for compatibility to hidden markov model learning code.
                    for (int i = 0; i < lstIA_Training_Sequences.Count - 1; i++)
                    {
                        intAA_Training_Sequences[i] = lstIA_Training_Sequences[i];
                    }

                    // have the HMM learn the new sequences
                    hmm_Current_Model.Learn(intAA_Training_Sequences, this.dbl_Hidden_Markov_Model_Threshold);

                    // update the hmm dictionary with the newly updated HMM.
                    dic_Hidden_Markov_Models[KVP.Key] = hmm_Current_Model;
                    continue;
                }
                else
                {
                    HiddenMarkovModel hmm_New_Model = new HiddenMarkovModel(2, 2);

                    // fracture the sequences into a series of int[]'s. this will be used to train the HMM.
                    List<int[]> lstIA_Training_Sequences = this.FractureIntSequence(KVP.Value);

                    // set the jagged array's length to the total number of datasets -- because the total number of datasets is the number of inputs to parse.
                    int[][] intAA_Training_Sequences = new int[lstIA_Training_Sequences.Count-1][];

                    // convert list<int[]> to int[][] -- needed for compatibility to hidden markov model learning code.
                    for (int i = 0; i < lstIA_Training_Sequences.Count - 1; i++)
                    {
                        intAA_Training_Sequences[i] = lstIA_Training_Sequences[i];
                    }
                       
                    // have the HMM learn the new sequences
                    hmm_New_Model.Learn(intAA_Training_Sequences, this.dbl_Hidden_Markov_Model_Threshold);

                    // update the hmm dictionary with the newly updated HMM.
                    dic_Hidden_Markov_Models.Add(KVP.Key, hmm_New_Model);
                    continue;
                }
            }
            return;
        } // end UpdateHiddenMarkovModels
        public void LoadHiddenMarkovModels(List<DataSet> lst_WMI_DataSets, Dictionary<string, string> dic_WMI_Classes)
        {
            ///<summary>
            /// Used on file load to train Hidden Markov Models.
            ///</summary>
            ///

            this.UpdateHiddenMarkovModels(lst_WMI_DataSets, dic_WMI_Classes);
            return;

        } // end LoadHiddenMarkovModels
        private List<DataSet> GetPropertyChanges(List<DataSet> lst_WMI_DataSets, Dictionary<string, string> dic_WMI_Classes)
        {
            // Gather the Entropy / Change Data

            // create a list of datasets to store the collection of property value change information.
            // this information is used for calculations later.
            List<DataSet> lst_DataSet_Differences = new List<DataSet>();

            // Comparison consists of: Going through each row of each table and cataloguing if the property values have changed from table A, to table B.
            // This information is stored as either a 0, (for no change), or a 1 (for change) and returned as a separate table.

            // for each DataSet in lst_WMI_DataSet_Collection.Count - 1:  -- lst_WMI_DataSet_Collection must have at least 2 DataSets for comparison.
            for (int i = 0; i < lst_WMI_DataSets.Count - 1; i++)
            {
                // Compare the tables within the data with the next DataSet's Corresponding Table of the same Name / WMI Class
                DataSet ds_Current_DataSet = lst_WMI_DataSets[i];
                DataSet ds_Next_DataSet = lst_WMI_DataSets[i + 1];

                // get differences
                DataSet ds_Differences = this.GetDataSetDifferences(ds_Current_DataSet, ds_Next_DataSet, dic_WMI_Classes);
                ds_Differences.DataSetName = ds_Current_DataSet.DataSetName;

                // add differences to list
                lst_DataSet_Differences.Add(ds_Differences);
            }

            return lst_DataSet_Differences;
        } // end GetEntropyTables
        private DataSet GetDataSetDifferences(DataSet ds_Current_DataSet, DataSet ds_Next_DataSet, Dictionary<string, string> dic_WMI_Classes)
        {
            // takes in 2 datasets, compares EACH property value that exists in each dataset, and returns a single dataset that contains binary information on whether each property changed or remained the same.
            // in order to compare the tables properly a column needs to be specified that contains unique information.
            // which column is used to do this depends on the WMI class and is obtained from the WMI Class Dictionary

            // build a dataset to contain the differences between the Current and Next DataSet
            DataSet ds_Differences = new DataSet();

            // Comparison consists of: Going through each row of each table and cataloguing if the property values have changed from table A, to table B.

            // for all tables in the current dataset... 
            for (int i = 0; i < ds_Current_DataSet.Tables.Count; i++)
            {
                // compare the table of the same name / index in the next dataset.
                DataTable dt_Current_Table = ds_Current_DataSet.Tables[i];

                // using the tablename of the current table instead of the index means that even if the system somehow gets the tables out of order, it doesn't matter.
                // the tables should always be in the same order, but why leave it to chance?
                DataTable dt_Facing_Table = ds_Next_DataSet.Tables[dt_Current_Table.TableName];

                // get unique column from dictionary to do comparison
                // the tablename is the name of the WMI class, so its used as the key for getting the column.

                // NOTE: this line will fail if the schema is changed unexpectedly / when using existing data (e.g. a class is added or removed from the WMI Class Dictionary, but information is loaded from the /data subdirectory)
                // This issue could be resolved by doing a schema comparison and failing gracefully if changes are found.

                if (dic_WMI_Classes.ContainsKey(dt_Current_Table.TableName))
                {
                    string str_Comparison_Column = dic_WMI_Classes[dt_Current_Table.TableName];

                    // compre each row in each of these tables, including headers, and catalogue differences.
                    DataTable dt_Differences = this.GetDataTableDifferences(dt_Current_Table, dt_Facing_Table, str_Comparison_Column);

                    // add the table that has stored the difference information to the dataset
                    ds_Differences.Tables.Add(dt_Differences);
                }
                else
                {
                    //Console.WriteLine("failure in dictionary key search. trying to find key {0}", dt_Current_Table.TableName);
                    //Console.WriteLine("this fault can happen if the files in the /data directory contain different schema information than the dictionary provided.");
                    //Console.WriteLine("delete information in the data subdirectory and restart the application.");
                    //Console.WriteLine("current dictionary contains the following:");
                    //foreach (KeyValuePair<string, string> KVP in dic_WMI_Class_Dictionary)
                    //{
                    //    Console.WriteLine("{0} {1}", KVP.Key, KVP.Value);
                    //}
                    continue;
                }
            }

            return ds_Differences;
        } // end GetDataSetDifferences
        private DataTable GetDataTableDifferences(DataTable dt_Current_Table, DataTable dt_Facing_Table, string str_Comparison_Column)
        {
            /// <summary>
            /// compares the differences between two tables; 
            /// returns a single table containing true/false information on property differences between two tables.
            /// </summary>

            // build temporary table to hold differences
            DataTable dt_Differences = new DataTable();

            // ensure table is properly named.
            dt_Differences.TableName = dt_Current_Table.TableName;

            // ensure table has proper headers / columns.
            foreach (DataColumn dc_Current_Column in dt_Current_Table.Columns)
            {
                // required because columns are instantied by reference; changing a column in one place changes ALL instances of the specific column
                // otherwise error thrown: "Column *** already belongs to another dataTable"
                // DataColumn dc_Cloned_Column = new DataColumn(dc_Current_Column.ColumnName, dc_Current_Column.DataType); 

                // STORE THE COLUMN NAME AS IS, BUT CHANGE THE DATA TYPE TO STRING; used for later comparison/maths.
                DataColumn dc_Cloned_Column = new DataColumn(dc_Current_Column.ColumnName, typeof(string));
                dt_Differences.Columns.Add(dc_Cloned_Column);
            }

            // verify tables are the correct shape; they MUST contain the same column names and types for this comparison to work.
            // note: (dt_Current_Table.Columns != dt_Facing_Table.Columns) DOES NOT WORK; each column is considering unique by reference, thus they never compare exactly the same.
            for (int i = 0; i < dt_Current_Table.Columns.Count; i++)
            {
                // if the columns have the same names, and the same datatypes, they are assumed to be the same columns.
                if (dt_Current_Table.Columns[i].ColumnName == dt_Facing_Table.Columns[i].ColumnName)
                {
                    if (dt_Current_Table.Columns[i].DataType == dt_Facing_Table.Columns[i].DataType)
                    {
                        continue;
                    }
                }
                else
                {
                    Console.WriteLine("fatal error: tables provided for comparison do not contain the same columns: {0}, {1}", dt_Current_Table.TableName, dt_Facing_Table.TableName);
                    System.Environment.Exit(1);
                    return dt_Differences;
                }
            }


            // compare each row in both tables; uses the comparison column to determine same row in both the current, and facing tables  
            for (int i = 0; i < dt_Current_Table.Rows.Count; i++)
            {
                // get the current row in the current table... 
                // the informations contained within it needs to be matched to appropriate row the facing data table.
                DataRow dr_Current_Row = dt_Current_Table.Rows[i];

                // to get the 2nd row for comparison, the column id -value- of the first row and the second row must intersect.
                // to find where this information intersects, you get the column index for the comparison column, then search for the appropriate values.

                // get the column ID number using the comaprison ID; this tells us the index on which to search the rows for unique values.
                int int_Comparison_Column_Index = dt_Current_Table.Rows[i].Table.Columns.IndexOf(str_Comparison_Column);

                // get the value that will be used to search for correct row in the facing table
                string str_Comparison_Value = (string)dr_Current_Row.ItemArray[int_Comparison_Column_Index];

                // using the column ID, get the values of rows in the facing table until a value is found that matches str_Comparison_Value;
                // THIS OPERATION IS VERY SLOW; ROWS CANNOT BE SORTED AND DO NOT HAVE AN INDEXING MECHANISM SUCH AS A PRIMARY OR FOREIGN KEY.

                // IMPORTANT: rows may not exist in the facing table; this is expected at times as information gets dropped.
                // this can occur frequently in some WMI classes, such as Win32_Process or Win32_NetworkAdapter.
                // the solution is to ignore it; missing rows will be accounted for in future iterations when computing entropy / probability of value changes.
                // this function does NOT account for fault sources.

                int count = 0; // tertiary; used for tracking what row in the table has been found to match; to be done: add this as a Key for fast finding after initial discovery.
                foreach (DataRow dr_Facing_DataRow in dt_Facing_Table.Rows)
                {
                    string str_Temporary_Comparison_Value = (string)dr_Facing_DataRow[int_Comparison_Column_Index];

                    // if the comparison value (which is supposed to be unique) is found in the row of the facing table
                    // then the correct row has been discovered and the next step is to do a comparison
                    if (str_Comparison_Value == str_Temporary_Comparison_Value)
                    {

                        // iterate through the itemarray in the current row, comparing objects returns in the facing row.
                        // if the object is an array, convert it to a string[], otherwise it will not compare properly.

                        string[] strA_Current_Row_Values = Core.ToStringArray(dr_Current_Row.ItemArray);
                        string[] strA_Facing_Row_Values = Core.ToStringArray(dr_Facing_DataRow.ItemArray);

                        // prep a datarow to be added to the differences table.
                        DataRow dr_Temporary_DataRow = dt_Differences.NewRow();
                        dt_Differences.Rows.Add(dr_Temporary_DataRow);
                        dr_Temporary_DataRow.BeginEdit();

                        // for each object in the current row, see if those same objects match or have changed in the facing row
                        for (int j = 0; j < dr_Current_Row.ItemArray.Length; j++)
                        {
                            // don't update the values in the table where the unique IDs are concerned.
                            if (j == int_Comparison_Column_Index)
                            {
                                if (dr_Current_Row[j].GetType().IsArray)
                                {
                                    string[] strA_Current_Row = Core.ToStringArray(dr_Current_Row[j]);
                                    dr_Temporary_DataRow.SetField(j, strA_Current_Row_Values[j]);
                                    continue;
                                }
                                else
                                {
                                    dr_Temporary_DataRow.SetField(j, strA_Current_Row_Values[j]);
                                    continue;
                                }

                            }

                            // if its not the unique id column, see if the value is either an array or not and update as normal.
                            if (dr_Current_Row[j].GetType().IsArray)
                            {
                                // if the objects are arrays, compare them as arrays
                                string[] strA_Current_Row = Core.ToStringArray(dr_Current_Row[j]);
                                string[] strA_Facing_Row = Core.ToStringArray(dr_Facing_DataRow[j]);

                                // if the values are the same, add a 0 to the temporary / entropy row
                                if (strA_Current_Row_Values[j] == strA_Facing_Row_Values[j])
                                {
                                    dr_Temporary_DataRow.SetField(j, "0");
                                    dr_Temporary_DataRow.AcceptChanges();
                                    dr_Temporary_DataRow.EndEdit();
                                    continue;
                                    // Console.WriteLine("VALUE AT COLUMN {1} IS {0} for {2}", dr_Temporary_DataRow[j].ToString(), dr_Temporary_DataRow.Table.Columns[j].ToString(), dt_Differences.TableName);
                                }
                                // if the values are different, add a 1 to the temporary / entropy row
                                if (strA_Current_Row_Values[j] != strA_Facing_Row_Values[j])
                                {
                                    dr_Temporary_DataRow.SetField(j, "1");
                                    dr_Temporary_DataRow.AcceptChanges();
                                    dr_Temporary_DataRow.EndEdit();
                                    // Console.WriteLine("VALUE AT COLUMN {1} IS {0} for {2}", dr_Temporary_DataRow[j].ToString(), dr_Temporary_DataRow.Table.Columns[j].ToString(), dt_Differences.TableName);
                                    continue;
                                }
                            }
                            else
                            {
                                // if the values are the same, add a 0 to the temporary / entropy row
                                if (strA_Current_Row_Values[j] == strA_Facing_Row_Values[j])
                                {
                                    dr_Temporary_DataRow.SetField(j, "0");
                                    dr_Temporary_DataRow.AcceptChanges();
                                    dr_Temporary_DataRow.EndEdit();
                                    continue;
                                    // Console.WriteLine("VALUE AT COLUMN {1} IS {0} for {2}", dr_Temporary_DataRow[j].ToString(), dr_Temporary_DataRow.Table.Columns[j].ToString(), dt_Differences.TableName);
                                }
                                // if the values are different, add a 1 to the temporary / entropy row
                                if (strA_Current_Row_Values[j].ToString() != strA_Facing_Row_Values[j].ToString())
                                {
                                    dr_Temporary_DataRow.SetField(j, "1");
                                    dr_Temporary_DataRow.AcceptChanges();
                                    dr_Temporary_DataRow.EndEdit();
                                    // Console.WriteLine("VALUE AT COLUMN {1} IS {0} for {2}", dr_Temporary_DataRow[j].ToString(), dr_Temporary_DataRow.Table.Columns[j].ToString(), dt_Differences.TableName);
                                    continue;
                                }
                            }
                        }
                        count = 0;
                        continue;
                    }
                    else
                    {
                        count++;
                        continue;
                    }
                }
            }

            return dt_Differences;
        } // end GetDataTableDifferences
        private Dictionary<string, int[]> CataloguePropertyChanges(List<DataSet> lst_Property_Change_Data, Dictionary<string, string> dic_WMI_Classes)
        {
            ///<summary>
            /// Converts property data into a binary sequence representing a history of whether or not the specific property did in fact change.
            ///</summary>

            // build an dictionary for storing property data and rates of change.
            // format: (WMI_CLASS_NAME)\(UNIQUE_IDENTIFIER_VALUE)\(COLUMN_NAME), (PROBABILITY_VALUE)

            // this method uses the list of datasets that store propery change information and unique IDs.
            // it returns a <string>,<int[]> dictionary that contains the path of the data property / feature, and a series of 0s and 1s that represent 

            Dictionary<string, int[]> dic_Feature_History = new Dictionary<string, int[]>();

            // using the list of datasets, go through each dataset and get the tables, rows, and eventually columns.
            foreach (DataSet ds_Current_DataSet in lst_Property_Change_Data)
            {
                foreach (DataTable dt_Current_Table in ds_Current_DataSet.Tables)
                {
                    foreach (DataRow dr_Current_Row in dt_Current_Table.Rows)
                    {
                        for (int i = 0; i < dt_Current_Table.Columns.Count; i++)
                        {
                            DataColumn dc_Current_Column = dt_Current_Table.Columns[i];
                            // WMI_CLASS name: comes from table; UNIQUE_IDENTIFIER_VALUE: comes from the current row where the index is that of the unique ID as specified by the unique ID dictionary.

                            // for each table, get the column to match unique ID.
                            string str_Unique_Column_Name = dic_WMI_Classes[dt_Current_Table.TableName];

                            // using this column name get the index where the unique ID information is stored.
                            // this value will allow the program to know where to pull the unique identifier value when making the dictionary key.
                            int int_Index_Of_Unique_Column = dt_Current_Table.Columns.IndexOf(str_Unique_Column_Name);

                            // do not try to parse the uniqueID column into the dictionary.
                            // this is because the values can sometimes be parsable integers.
                            // also, changes in the unique column are already accounted for in the probability table
                            // thus there is no reason to track it twice by adding it to dictionary again.
                            if (i == int_Index_Of_Unique_Column)
                            {
                                continue;
                            }

                            // finally, populate the dictionary
                            // build the dictionary key
                            string str_Dictionary_Key = dt_Current_Table.TableName + @"\" + dr_Current_Row.ItemArray[int_Index_Of_Unique_Column] + @"\" + dc_Current_Column.ColumnName;

                            // get the value associated with the key -- this value should be either a 0 or a 1.
                            int int_Value = 0;
                            bool boo_Result_Of_TryParse = Int32.TryParse((string)dr_Current_Row[dc_Current_Column], out int_Value);

                            if (boo_Result_Of_TryParse == false)
                            {
                                // if the parse to an int failed, then an exception should be thrown
                                // to be implemented later.
                                Console.WriteLine("failed to parse {0}", (string)dr_Current_Row[dc_Current_Column]);
                                continue;
                            }
                            else
                            {
                                // if the value is an int, it should always be either a zero or a 1
                                // update the value of the dictionary as normal.
                                if (dic_Feature_History.ContainsKey(str_Dictionary_Key))
                                {
                                    // if the key IS in the dictionary, get the length of the current feature history and append the obtained change value.
                                    int int_Value_To_Append = int_Value;
                                    int int_Index_To_Insert_Value = dic_Feature_History[str_Dictionary_Key].Length;

                                    // copy the existing data into a new array; then update the value at the correct index marker (i).
                                    int[] intA_Current_Integer_Array = dic_Feature_History[str_Dictionary_Key];
                                    int[] intA_New_Integer_Array = new int[intA_Current_Integer_Array.Length + 1]; // extend the int[] array by 1

                                    // clone the data from the existing array into the new array.
                                    for (int j = 0; j < intA_Current_Integer_Array.Length; j++)
                                    {
                                        intA_New_Integer_Array[j] = intA_Current_Integer_Array[j];
                                    }

                                    // append the new value to the end of the array.
                                    intA_New_Integer_Array[intA_Current_Integer_Array.Length] = int_Value;

                                    // update the dictionary
                                    dic_Feature_History[str_Dictionary_Key] = intA_New_Integer_Array;
                                    continue;
                                }
                                else
                                {
                                    // if the key is NOT in the dictionary, add a new dictionary key that has an integer array which contains the first feature history data value.
                                    int[] intA_New_Integer_Array = new int[1];

                                    // populate initial value of array.
                                    intA_New_Integer_Array[0] = int_Value;

                                    // update dictionary
                                    dic_Feature_History.Add(str_Dictionary_Key, intA_New_Integer_Array);
                                    continue;
                                }
                            }

                        } // end Foreach DataColumn
                    } // end Foreach DataRow
                } // end Foreach DataTable
            } // end Foreach DataSet

            return dic_Feature_History;
        } // end GetFeatureHistory.
        public System.Linq.IOrderedEnumerable<Fault> GetFaults()
        {
            // once complete, sort the list by likelihood...
            var var_Faults = lst_Faults.OrderByDescending(x => x.Confidence);
            return var_Faults;
        } // end GetFaults
        private List<int[]> FractureIntSequence(int[] intA_Sequence)
        {
            // takes in an integer array and returns a list of integers built from subsequent iterative combination: 
            // e.g.
            // Input => 0,0,1  
            // 0
            // 0,0
            // 0,0,1

            // this method is used to train hidden markov models by breaking down a feature's behavioural histories...

            int count = 1;
            int end = intA_Sequence.Length;

            List<int[]> lstIA_Sequences = new List<int[]>();

            int[] intA_Current_Sequence = new int[1];

            // for the whole length of the sequence...

            while (count < end + 1)
            {
                for (int i = 0; i < count; i++)
                {
                    if (intA_Sequence != null)
                    {
                        intA_Current_Sequence[i] = intA_Sequence[i];
                    }
                    else continue;
                }
                lstIA_Sequences.Add(intA_Current_Sequence);
                intA_Current_Sequence = Core.ExtendIntArray(intA_Current_Sequence);
                count++;

            }

            return lstIA_Sequences;
        } // end FractureIntSequence
        public int ListSize()
        {
            return lst_Faults.Count;
        } // end ListSize

    } // end Class Analyser

    public class Classifier
    {
        ///<summary>
        /// This class contains methods that attempt to determine a faulty or functional systems state.
        /// It contains: A series of methods that evaluate the state of the system by using 'fitness tests'.
        /// Each method is programmed individually, but is designed to emulate human specified 'policies'.
        /// 
        /// For example, if software on a system that should have a persisent internet connection: 
        /// It can be evaluted by determining the state of its network connectivity using a single, simple test.
        /// The results of these tests are not parsed other than whether or not they are successful.
        /// 
        /// The purpose of the classifier is ONLY to determine IF the systems is faulting, but not where or why.
        ///</summary>

        public Classifier()
        {
            // default constructor - inits go here on object instantiation; 
        } // end Default Constructor
        public bool Run()
        {
            // Initialise the Classifier; Run appropriate tests.
            // If all tests return true, return true from run.
            //  Else, return false.

            // used for certain tests; chosen based on likelihood of availability.
            List<string> lst_URLs = new List<string>();

            lst_URLs.Add("www.google.com");
            lst_URLs.Add("www.yahoo.com");
            lst_URLs.Add("www.microsoft.com");

            // used to store the results of all fitness tests.
            List<bool> lst_Test_Results = new List<bool>();

            // test base operating system / networking
            lst_Test_Results.Add(this.CheckDiskAccess());
            lst_Test_Results.Add(this.CheckDNSStatus(lst_URLs));
            lst_Test_Results.Add(this.CheckPhysicalMemoryStatus());
            lst_Test_Results.Add(this.CheckIPStatus());

            // test web services
            lst_Test_Results.Add(this.CheckServiceRunning("w3svc"));
            lst_Test_Results.Add(this.GetWebPage("http://localhost"));

            // verify the results in the lst_Check_Results 
            foreach (bool b in lst_Test_Results)
            {
                if (b == false)
                {
                    return false;
                }
                else continue;
            }

            // if all values are true, return true.
            return true;
        } // end Run
        private bool CheckDiskAccess() // end CheckDiskAccess
        {
            // Verify non-volatile storage is operating as expected.

            // write a file to the local disk
            // delete the file from the local disk
            // ensure free space?

            // get application directory path & current drive
            string str_Application_Path = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string str_Current_Drive = str_Application_Path.Substring(0, 3);

            // get an array of drives connected to the system.
            DriveInfo[] di_Drives = DriveInfo.GetDrives();
            foreach (DriveInfo di_Drive in di_Drives)
            {
                // if the device has a mounted volume and is the current drive
                if (di_Drive.IsReady && di_Drive.Name.ToString() == str_Current_Drive)
                {

                    // get the available free space
                    Int64 i64_Free_Space = di_Drive.AvailableFreeSpace;

                    // make sure we have at least 100 MBs free.
                    if (i64_Free_Space < 104857600)
                    {
                        Console.WriteLine("drive {0} did not have enough free space. availabile space: {1}", str_Current_Drive, i64_Free_Space);
                        return false;
                    }
                    else return true;
                } // if the device is not the drive from where this program is running, or it is not ready, continue.
                else continue;
            }
            return true;
        }
        private bool CheckPhysicalMemoryStatus() // end CheckFreeMemory
        {
            // ensure memory can be allocated, written to, and released


            UInt64 ui64_Total_Physical_Memory = this.GetTotalPhysicalMemory();
            UInt64 ui64_Available_Physical_Memory = this.GetAvailablePhysicalMemory();
            float flt_Percent_Free_Memory = ((float)ui64_Available_Physical_Memory / ui64_Total_Physical_Memory) * 100;

            // if we have at least 5% available free memory, return true.
            if (flt_Percent_Free_Memory >= 5)
            {
                return true;
            }

            // if we have less than 5% available free memory, attempt to write a 16KB block/page; 
            // if successful, return true, else return false.
            if (flt_Percent_Free_Memory < 5)
            {
                try
                {
                    string str_Memory_Test_String = "";
                    int int_Length_Of_Test_String = 16384;

                    for (int i = 0; i < int_Length_Of_Test_String; i++)
                    {
                        str_Memory_Test_String = str_Memory_Test_String + "0";
                    }
                    return true;
                }

                catch (Exception e)
                {
                    Console.WriteLine("error while attempting to test physical memory availablity. {0}", e.Message);
                    return false;
                }
            }
            else return false;

        }
        private UInt64 GetTotalPhysicalMemory()
        {
            UInt64 ui64_TotalPhysicalMemory = 0;

            string str_Query = "SELECT * FROM Win32_ComputerSystem";
            ManagementObjectSearcher mos_Searcher = new ManagementObjectSearcher(str_Query);
            foreach (ManagementObject mo_ComputerSystem in mos_Searcher.Get())
            {
                UInt64 SizeinBytes = Convert.ToUInt64(mo_ComputerSystem.Properties["TotalPhysicalMemory"].Value);
                ui64_TotalPhysicalMemory = SizeinBytes;
            }

            return ui64_TotalPhysicalMemory;
        } // end GetTotalPhysicalMemory
        private UInt64 GetAvailablePhysicalMemory() // end GetAvailablePhysicalMemory
        {
            ///<summary> 
            /// Gets the Available Physical Memory on a system in Bytes; Returns a UInt64.
            ///</summary>
            ///
            UInt64 ui64_Available_System_Memory = 0;

            string str_Query = "SELECT * FROM Win32_OperatingSystem";
            ManagementObjectSearcher mos_Searcher = new ManagementObjectSearcher(str_Query);

            foreach (ManagementObject mo_OperatingSystem in mos_Searcher.Get())
            {
                string str_Available_Physical_Memory_In_KB = mo_OperatingSystem["FreeVirtualMemory"].ToString();

                try
                {
                    UInt64 ui64_Temporary_Physical_Memory_In_KB = UInt64.Parse(str_Available_Physical_Memory_In_KB);
                    UInt64 ui64_Temporary_Physical_Memory_In_Bytes = ui64_Temporary_Physical_Memory_In_KB * 1024;
                    ui64_Available_System_Memory = ui64_Temporary_Physical_Memory_In_Bytes;
                }
                catch (Exception e)
                {
                    Console.WriteLine("failure parsing available physical memory via WMI. {0}", e.Message);
                    return 0;
                }
            }

            return ui64_Available_System_Memory;

        }
        private bool CheckDNSStatus(List<string> lst_Hostnames)
        {
            // takes in a list of hostnames and attempts to resolve each to their respective IPs.
            // on failure returns false; success on ALL hostnames, true.

            List<bool> lst_DNS_Statuses = new List<bool>();

            foreach (string str_URL in lst_Hostnames)
            {
                try
                {
                    // attempt to resolve the hostname to an IP.
                    IPHostEntry iphe_IPHostEntries = Dns.GetHostEntry(str_URL);

                    // if the hostname resolves, and there is at least one IP address returned, continue on to the next hostname.
                    if (iphe_IPHostEntries.AddressList.Length > 0)
                    {
                        continue;
                    }
                    else return false;
                }
                catch (Exception e)
                {
                    Console.WriteLine("failure in DNS resolution of {0}. {1}", str_URL, e.Message);
                    return false;
                }
            }

            return true;
        } // end CheckDNSStatus
        private bool CheckIPStatus() // end CheckIPStatus
        {
            // test the Internet Protocol 
            // uses ping to get to 4.2.2.4, and 127.0.0.1

            bool boo_Localhost_Ping_Result = this.Ping("127.0.0.1");
            bool boo_Remotehost_Ping_Result = this.Ping("4.2.2.4");

            if (boo_Localhost_Ping_Result && boo_Remotehost_Ping_Result)
            {
                return true;
            }
            else return false;
        }
        private bool Ping(string str_Hostname)
        {
            /// <summary>
            /// This function sends a simple Ping (ICMP request) to any provided hostname.
            /// </summary>
            /// 
            try
            {
                byte[] byt_Buffer = new byte[32];
                int int_Timeout = 1000;

                Ping png_Ping = new Ping();
                PingOptions po_PingOptions = new PingOptions();
                po_PingOptions.Ttl = 30;

                PingReply pr_Reply = png_Ping.Send(str_Hostname, int_Timeout, byt_Buffer, po_PingOptions);

                if (pr_Reply.Status == IPStatus.Success)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("failure pinging host {1}. {0}", str_Hostname, e.Message);
                return false;
            }

        } // end Ping
        private bool CheckServiceRunning(string str_Name_Of_Service) // end CheckServiceRunning
        {
            // given a string, match a running service on the local system
            try
            {
                ServiceController sc_WindowsService = new ServiceController(str_Name_Of_Service);

                switch (sc_WindowsService.Status)
                {
                    case ServiceControllerStatus.Running:
                        return true;
                    case ServiceControllerStatus.Stopped:
                        return false;
                    case ServiceControllerStatus.Paused:
                        return false;
                    case ServiceControllerStatus.StopPending:
                        return false;
                    case ServiceControllerStatus.StartPending:
                        return false;
                    default:
                        Console.WriteLine("service state could not be determined for {0}.", str_Name_Of_Service);
                        return false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("a specified service ({0}) could not be queried on this system. {1}", str_Name_Of_Service, e.Message);
                return false;
            }

        }
        private bool GetWebPage(string str_URL)
        {
            // edited/taken from http://stackoverflow.com/questions/2031824/check-for-internet-connectivity

            ///<summary>
            /// This method attempts to open a stream to a provided URL; this tests external network connectivity via www requests; assumes IP protocol.
            ///</summary>

            try
            {
                using (var client = new WebClient())
                using (var stream = client.OpenRead(@str_URL))
                {
                    // if the steam is able to be created, return true.
                    // any errors found such as 400s, 500s, etc are ignored -- we dont care about the servers state.
                    // this is because if the webclient object has been able to receive an error the problem is always going to be external.
                    return true;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("failure connecting to host {0}. {1}", str_URL, e.Message);
                return false;
            }
        } // end ConnectToWebSite

    } // end class Classifier

    public class Metrics
    {
        ///<summary>
        /// Gathers metrics once a fault is detected.
        /// Metrics include:
        /// 
        ///     How long it took from the time the fault was detected, to when the sorted list of potential faults was produced.
        ///     The amount of memory used
        ///     The total size of the list
        ///     
        ///     Precision   =   tp/tp+fp
        ///     Accuracy    =   tp+tn/everything
        ///     Recall      =   tp/tp+fn
        ///     
        ///     F-Measure / Harmonic Mean  =  Precision * Recall / Precision + Recall
        ///</summary>
        // BGN LOCAL VARS 

        System.Diagnostics.Stopwatch sw_StopWatch = new System.Diagnostics.Stopwatch();         // Determines how long the fault analysis took -- note: MUST USE ELAPSED MILLISECONDS FOR CONSISTENCY DUE TO PROBLEMS WITH C#.
        long lng_Time_Taken = 0;                                                                // Number of milliseconds it took to populate the fault list.
        int int_List_Size = 0;                                                                  // The total number of changed features found by the analyser
  
        double dbl_Precision = 0.0;                                                             // Precision = true positives / true positives + false positives
        double dbl_Accuracy = 0.0;                                                              // Accuracy = true positives + true negatives / everything
        double dbl_Harmonic_Mean = 0.0;                                                         // F-Measure / Harmonic Mean = precision * recall / precision + recall
        double dbl_Recall = 0.0;                                                                // Recall = true positives / true positives + false negatives

        // END LOCAL VARS
        
        public void Start()
        {
            // start all collectors
            sw_StopWatch.Start();
        }

        public void Stop(Analyser an_Analyser, int int_False_Negatives, int int_False_Positives, int int_True_Negatives, int int_True_Positives, int int_Total_Configurations_Examined)
        {
            // stop all collectors
            sw_StopWatch.Stop();
            
            // get list length -- this represents the current number of configurations in the collection
            int_List_Size = this.ListSize(an_Analyser);

            // get total time taken from when fault was discovered to when list was produced.
            lng_Time_Taken = sw_StopWatch.ElapsedMilliseconds;

            // produce the necessary metrics
            // to do this we need 4 values:

            //      FALSE NEGATIVE: Application DIDNT detect a fault and a fault IS present.
            //      FALSE POSITIVE: Application DID detect a fault and a fault IS NOT present.
			//      TRUE NEGATIVE:  Application DIDNT detect a fault and a fault IS NOT present.
            //      TRUE POSITIVE:  Application DID detect a fault and a fault IS present.
	 	
            // these values produce the following measurements

            //      Precision = true positives / true positives + false positives               
            //      Accuracy = true positives + true negatives / everything
            //      F-Measure / Harmonic Mean = precision * recall / precision + recall
            //      Recall = true positives / true positives + false negatives

            // get the number of faults not detected by the application -- this must be supplied by the user, a priori.
            int_False_Negatives = this.FalseNegatives(int_False_Negatives);

            // get the number of times the application detected faults when there were NOT any faults
            // already calculated :: int_False_Positives;

            // get the number of times the application DID NOT detect a fault, and a fault was NOT present
            // take the total number of configurations examined that passed their fitness tests, 
            //  minus the times the application did not detect a fault when one was present, and
            //  minus the number of times the application DID detect a fault when one was not present.
            int_True_Negatives = int_Total_Configurations_Examined - int_False_Positives - int_False_Negatives - int_True_Positives;

            // correct for negative values of true negatives--this should never happen, but, we all know that values that should never happen occasionally do!
            if (int_True_Negatives < 0)
                int_True_Negatives = 0;

            // get the number of faults legitimately detected--this should be 1 as the application will fail on the first time it detects a fault.
            // already calculated :: int_True_Positives

            // generate core metrics / measurements:
            dbl_Precision = this.Precision(int_True_Positives, int_False_Positives);
            dbl_Recall = this.Recall(int_True_Positives, int_False_Negatives);
            dbl_Harmonic_Mean = this.Harmonic_Mean(dbl_Precision, dbl_Recall);
            dbl_Accuracy = this.Accuracy(int_True_Positives, int_True_Negatives, int_False_Positives, int_False_Negatives);

            // cs2501x specific metrics-- because the list is sorted, we should be able to identify how accurate the fault detection is.
            // is the fault present in the list? only a human would know...
            // if so, what position is it in the list?
            // if not, was the fitness test accurate? -- faulty fitness tests mean false positives.

            // print top 5 results? if fault is in the top 5, list it as being correct--

            List<string> lstS_Fault_Data = this.FaultData(an_Analyser);
            int int_Total_Potential_Faults_List_Count = an_Analyser.GetFaults().Count();

            // display the results.
            Console.Write("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},", dbl_Precision, dbl_Recall, dbl_Harmonic_Mean, dbl_Accuracy, int_False_Negatives, int_False_Positives, int_True_Negatives, int_True_Positives, lng_Time_Taken, int_Total_Potential_Faults_List_Count);
            foreach (string s in lstS_Fault_Data) 
            {
                Console.Write(s + ",");
            }
        }

        private int FalseNegatives(int int_False_Negatives)
        {
            // ask the user for number of false negatives : 
            Console.WriteLine("Number of faults not detected by the application: (False Negatives) ");
            string str_User_Input_False_Negatives = Console.ReadLine();

            string str_Temp_Input = "";

            // sanitise the user input:
            foreach (char c in str_User_Input_False_Negatives)
            {
                if (char.IsDigit(c) == true)
                {
                    str_Temp_Input = str_Temp_Input + c.ToString();
                }
                else continue;
            }

            // convert the sanitised user input to an integer
            int int_User_Specified_False_Negatives = 0;
            bool boo_Parse_Status = Int32.TryParse(str_Temp_Input, out int_User_Specified_False_Negatives);

            // if successfully parsed, update false negatives
            if (boo_Parse_Status == true)
            {
                int_False_Negatives = int_False_Negatives + int_User_Specified_False_Negatives;
                return int_False_Negatives;
            }
            else return 0;
        } // end GetFalseNegatives
        private double Precision(int int_True_Positives, int int_False_Positives)
        {
            // Precision is the probability that a (randomly selected) retrieved document is relevant.
            // Precision = true positives / true positives + false positives

            double dbl_Result = (double) int_True_Positives / (int_True_Positives + int_False_Positives);
            return dbl_Result;
        } // end Precision
        private double Recall(int int_True_Positives, int int_False_Negatives)
        {
            // Recall is the probability that a (randomly selected) relevant document is retrieved in a search.
            // Recall = true positives / true positives + false negatives

            double dbl_Result = (double) int_True_Positives / (int_True_Positives + int_False_Negatives);
            return dbl_Result;
        } // end Recall
        private double Harmonic_Mean(double dbl_Precision, double dbl_Recall)
        {
            // The Harmonic Mean emphaises the influence of outliers and small values while still presenting a rational sense of average behaviours and performance.
            // F-Measure / Harmonic Mean = precision * recall / precision + recall
            double dbl_Result = (double) dbl_Precision * dbl_Recall / (double)(dbl_Precision + dbl_Recall);
            return dbl_Result;
        } // end Harmonic_Mean
        private double Accuracy(int int_True_Positives, int int_True_Negatives, int int_False_Positives, int int_False_Negatives)
        {
            // How close the value is to the expected result -- when a fault was present, was it detected?
            // Accuracy = true positives + true negatives / everything
            double dbl_Result = (double)int_True_Positives + int_True_Negatives / (double)(int_True_Positives + int_True_Negatives + int_False_Positives + int_False_Negatives);
            return dbl_Result;
        } // end Accuracy
        public int ListSize(Analyser an_Analyser)
        {
            return an_Analyser.ListSize();
        } // end ListSize
        private List<string> FaultData(Analyser an_Analyser)
        {
            // is the fault in the list of changed properties within the analyser object?
            // if so, record the fault, its position in the list, and the confidence value of the HMM
            // if not, return -1.

            List<string> lstS_Fault_Data = new List<string>();

            // get a list of faults
            System.Linq.IOrderedEnumerable<Fault> IOEnum_Faults = an_Analyser.GetFaults();
            List<Fault> lst_Faults = IOEnum_Faults.ToList<Fault>();

            // list the faults for the user
            for (int i = 0; i < lst_Faults.Count; i++)
            {
                Console.WriteLine("{0}\t{1}\t{2}", i, lst_Faults[i].Source, lst_Faults[i].Confidence);    
            }

            // prompt the user to verify the position of the faults
            Console.WriteLine("enter line number of fault source.");
            string str_User_Input_False_Negatives = Console.ReadLine();
            string str_Temp_Input = "";

            // sanitise the user input:
            foreach (char c in str_User_Input_False_Negatives)
            {
                if (char.IsDigit(c) == true)
                {
                    str_Temp_Input = str_Temp_Input + c.ToString();
                }
                else continue;
            }

            // convert the sanitised user input to an integer
            int int_User_Specified_Index_Value = 0;
            bool boo_Parse_Status = Int32.TryParse(str_Temp_Input, out int_User_Specified_Index_Value);

            if (boo_Parse_Status == false)
            {
                Console.WriteLine("user input failed integer parse validation.");
                return new List<string> {"-1","-1","-1"};
            }
            else 
            {
                var f = lst_Faults[int_User_Specified_Index_Value];
                lstS_Fault_Data.Add(int_User_Specified_Index_Value.ToString());
                lstS_Fault_Data.Add(f.Source);
                lstS_Fault_Data.Add(f.Confidence.ToString());
                return lstS_Fault_Data;
            }
            
        }

    } // end Class Metrics

    public static class CimConverter
    {
        // taken from http://stackoverflow.com/questions/2905560/convert-wmi-cimtype-to-system-type

        private readonly static IDictionary<CimType, Type> Cim2TypeTable = new Dictionary<CimType, Type>
        {
            {CimType.Boolean, typeof (bool)},
            {CimType.Char16, typeof (string)},
            {CimType.DateTime, typeof (DateTime)},
            {CimType.Object, typeof (object)},
            {CimType.Real32, typeof (decimal)},
            {CimType.Real64, typeof (decimal)},
            {CimType.Reference, typeof (object)},
            {CimType.SInt8, typeof (sbyte)},
            {CimType.SInt16, typeof (short)},
            {CimType.SInt32, typeof (int)},
            {CimType.SInt64, typeof (long)},
            {CimType.String, typeof (string)},
            {CimType.UInt8, typeof (byte)},
            {CimType.UInt16, typeof (ushort)},
            {CimType.UInt32, typeof (uint)},
            {CimType.UInt64, typeof (ulong)},
        };

        public static Type Cim2SystemType(this PropertyData data)
        {
            Type type = Cim2TypeTable[data.Type];
            if (data.IsArray)
            {
                type = type.MakeArrayType();
                return type;
            }
            else return type;
        }

        public static object Cim2SystemValue(this PropertyData pd_Property_Data)
        {
            Type type = Cim2SystemType(pd_Property_Data);
            if (pd_Property_Data.Type == CimType.DateTime)
            {
                DateTime ret = CimConverter.ToDateTime(pd_Property_Data.ToString());

                //string format = "yyyyMMddHHmmss.ffffff";
                //string val = pd_Property_Data.Value.ToString().Substring(0, format.Length);
                //DateTime ret = DateTime.ParseExact(val, format, CultureInfo.InvariantCulture);
                return ret;
            }
            return Convert.ChangeType(pd_Property_Data.Value, type);
        }

        public static DateTime ToDateTime(object obj_CIM_DateTime)
        {
            int year = DateTime.Now.Year;
            int month = 1;
            int day = 1;
            int hour = 0;
            int minute = 0;
            int second = 0;
            int millisec = 0;

            if (obj_CIM_DateTime == null)
            {
                return DateTime.MinValue;
            }
            else
            {
                string str_CIM_DateTime = obj_CIM_DateTime as string;

                if (((String.Empty == str_CIM_DateTime) || (str_CIM_DateTime == null)))
                {
                    return DateTime.MinValue;
                }

                if ((str_CIM_DateTime.Length != 25))
                {
                    return DateTime.MinValue;
                }

                year = Int32.Parse(str_CIM_DateTime.Substring(0, 4));
                month = Int32.Parse(str_CIM_DateTime.Substring(4, 2));
                day = Int32.Parse(str_CIM_DateTime.Substring(6, 2));
                hour = Int32.Parse(str_CIM_DateTime.Substring(8, 2));
                minute = Int32.Parse(str_CIM_DateTime.Substring(10, 2));
                second = Int32.Parse(str_CIM_DateTime.Substring(12, 2));
                millisec = Int32.Parse(str_CIM_DateTime.Substring(15, 3));

            }

            DateTime dt_DateTime = new DateTime(year, month, day, hour, minute, second, millisec);

            return dt_DateTime;
        }

    } // end CimConvert

    public class Fault
    {
        public string Source;
        public double Confidence;

    } // end Fault
}