Steps for Reproduction & Generating Results:

To validate the approach we have described in "Autonomous Fault
Detection in Self-Healing Systems: Comparing Hidden Markov Models
and Artificial Neural Networks", the following steps should
be taken:

1) Install Windows 7 x64 onto a virtual instance.
2) Configure the system to have three volumes on a single disk partition: C, D, and E.
3) Install IIS on to E: using the Windows Add/Remove Programs feature.
4) Place all files from this archive on D: in a directory of your choosing. 
5) Ensure that the Windows 7 system has access to the internet.
6) Navigate to either the HMM or ANN bin/debug directory and run the binary. It should begin collecting data.
7) After 30 minutes, stop the binary and take a snapshot of the system.
8) Attempt to perform any of the tests described in the paper--e.g., 
   disabling the IIS web service, removing the E partition through 
   the disk management MMC snap in, etc.
   If you wish to use less data for comparing the results simply delete some of the .XML or .SCHEMA files in the /data sub-directory.
   If any corruption occurs simply delete the data in this sub-directory and start again.
9) The application framework should fault and provide a list of potential root causes.

Necessary Artifacts:

Windows 7 x64 Virtual Machine Instance.
A copy of the C# ADF code / binaries.
C# .NET framwork 4.0 or later.
Access to the internet.
