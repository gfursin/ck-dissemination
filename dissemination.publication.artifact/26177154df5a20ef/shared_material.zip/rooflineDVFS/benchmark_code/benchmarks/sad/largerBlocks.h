/***************************************************************************
 *cr
 *cr            (C) Copyright 2007 The Board of Trustees of the
 *cr                        University of Illinois
 *cr                         All Rights Reserved
 *cr
 ***************************************************************************/

__global__ void larger_sad_calc_8(unsigned short*, int, int);
__global__ void larger_sad_calc_16(unsigned short*, int, int);
